import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import axios from 'axios';
import './App.css';

// Import Chart components
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Import UI components
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import { AlertCircle, BookOpen, MapPin, Calendar, Users, Award, Briefcase, GraduationCap, BarChart3, TrendingUp, Bookmark, Star } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Color schemes for charts
const STREAM_COLORS = {
  Science: '#3b82f6',
  Commerce: '#10b981', 
  Arts: '#f59e0b',
  Vocational: '#ef4444'
};

const COURSE_COLORS = {
  'B.Sc': '#3b82f6',
  'B.Com': '#10b981',
  'B.A': '#f59e0b',
  'BCA': '#8b5cf6',
  'BBA': '#ef4444'
};

// Main App Component
function App() {
  const [currentStudent, setCurrentStudent] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <BrowserRouter>
        <div className="container mx-auto px-4 py-8">
          <header className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">
              🎓 AI Career Guidance Platform
            </h1>
            <p className="text-gray-600 text-lg">
              Your personalized path to academic and career success with real data
            </p>
          </header>

          <Routes>
            <Route path="/" element={
              <Welcome 
                setCurrentStudent={setCurrentStudent}
              />
            } />
            <Route path="/student/:studentId" element={
              <StudentDashboard 
                currentStudent={currentStudent}
                setCurrentStudent={setCurrentStudent}
              />
            } />
            <Route path="/assessment/:studentId" element={
              <EnhancedAssessmentFlow />
            } />
            <Route path="/colleges" element={<CollegeExplorer />} />
            <Route path="/courses" element={<CourseExplorer />} />
            <Route path="/news" element={<NewsUpdates />} />
            <Route path="/jobs" element={<JobOpportunities />} />
          </Routes>
        </div>
      </BrowserRouter>
    </div>
  );
}

// Welcome Screen Component
const Welcome = ({ setCurrentStudent }) => {
  const [studentId, setStudentId] = useState('');

  const handleExistingStudent = async () => {
    if (!studentId.trim()) {
      alert('Please enter your Student ID');
      return;
    }

    try {
      const response = await axios.get(`${API}/students/${studentId}`);
      setCurrentStudent(response.data);
      window.location.href = `/student/${studentId}`;
    } catch (error) {
      alert('Student not found. Please create a new profile.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="p-6 hover-lift">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-600" />
              New Student
            </CardTitle>
            <CardDescription>
              Create your profile and get AI-powered career guidance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <StudentRegistrationForm setCurrentStudent={setCurrentStudent} />
          </CardContent>
        </Card>

        <Card className="p-6 hover-lift">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-green-600" />
              Existing Student
            </CardTitle>
            <CardDescription>
              Continue your career exploration journey
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="studentId">Enter your Student ID</Label>
              <Input
                id="studentId"
                placeholder="Enter your unique student ID"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
              />
            </div>
            <Button onClick={handleExistingStudent} className="w-full">
              Continue Journey
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced Feature Overview */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-6">
        <FeatureCard
          icon={<GraduationCap className="h-8 w-8" />}
          title="AI Assessment"
          description="OpenAI-powered aptitude evaluation with graphs"
          color="text-blue-600"
        />
        <FeatureCard
          icon={<MapPin className="h-8 w-8" />}
          title="Real Colleges"
          description="Live data from government websites"
          color="text-green-600"
        />
        <FeatureCard
          icon={<Briefcase className="h-8 w-8" />}
          title="Live Jobs"
          description="Real job opportunities and salaries"
          color="text-purple-600"
        />
        <FeatureCard
          icon={<BarChart3 className="h-8 w-8" />}
          title="Visual Analytics"
          description="Stream & course preferences as graphs"
          color="text-orange-600"
        />
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, description, color }) => (
  <Card className="text-center p-4 hover-lift interactive-card">
    <CardContent className="pt-4">
      <div className={`${color} mb-2 flex justify-center`}>{icon}</div>
      <h3 className="font-semibold mb-2">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </CardContent>
  </Card>
);

// Student Registration Form
const StudentRegistrationForm = ({ setCurrentStudent }) => {
  const [formData, setFormData] = useState({
    name: '',
    class_level: '',
    age: '',
    gender: '',
    state: '',
    district: '',
    preferred_language: 'English'
  });
  const [loading, setLoading] = useState(false);

  const indianStates = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
    'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
    'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
    'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan',
    'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh',
    'Uttarakhand', 'West Bengal'
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post(`${API}/students`, {
        ...formData,
        age: parseInt(formData.age)
      });
      
      setCurrentStudent(response.data);
      alert(`Welcome ${response.data.name}! Your Student ID is: ${response.data.id}\n\nPlease save this ID for future access.`);
      window.location.href = `/student/${response.data.id}`;
    } catch (error) {
      alert('Error creating profile. Please try again.');
      console.error('Registration error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Full Name *</Label>
        <Input
          id="name"
          required
          value={formData.name}
          onChange={(e) => setFormData({...formData, name: e.target.value})}
          placeholder="Enter your full name"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="class_level">Current Class *</Label>
          <Select required onValueChange={(value) => setFormData({...formData, class_level: value})}>
            <SelectTrigger>
              <SelectValue placeholder="Select class" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="10">Class 10</SelectItem>
              <SelectItem value="12">Class 12</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="age">Age *</Label>
          <Input
            id="age"
            type="number"
            required
            min="14"
            max="25"
            value={formData.age}
            onChange={(e) => setFormData({...formData, age: e.target.value})}
            placeholder="Age"
          />
        </div>
      </div>

      <div>
        <Label htmlFor="gender">Gender *</Label>
        <Select required onValueChange={(value) => setFormData({...formData, gender: value})}>
          <SelectTrigger>
            <SelectValue placeholder="Select gender" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Male">Male</SelectItem>
            <SelectItem value="Female">Female</SelectItem>
            <SelectItem value="Other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="state">State *</Label>
        <Select required onValueChange={(value) => setFormData({...formData, state: value})}>
          <SelectTrigger>
            <SelectValue placeholder="Select state" />
          </SelectTrigger>
          <SelectContent>
            {indianStates.map(state => (
              <SelectItem key={state} value={state}>{state}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="district">District *</Label>
        <Input
          id="district"
          required
          value={formData.district}
          onChange={(e) => setFormData({...formData, district: e.target.value})}
          placeholder="Enter your district"
        />
      </div>

      <div>
        <Label htmlFor="language">Preferred Language</Label>
        <Select onValueChange={(value) => setFormData({...formData, preferred_language: value})}>
          <SelectTrigger>
            <SelectValue placeholder="English" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="English">English</SelectItem>
            <SelectItem value="Hindi">Hindi (हिंदी)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button type="submit" disabled={loading} className="w-full">
        {loading ? 'Creating Profile...' : 'Create Profile & Start AI Assessment'}
      </Button>
    </form>
  );
};

// Enhanced Student Dashboard Component
const StudentDashboard = ({ currentStudent, setCurrentStudent }) => {
  const [studentData, setStudentData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStudentData = async () => {
      const studentId = window.location.pathname.split('/')[2];
      if (studentId) {
        try {
          const response = await axios.get(`${API}/students/${studentId}`);
          setStudentData(response.data);
          setCurrentStudent(response.data);
        } catch (error) {
          console.error('Error fetching student data:', error);
        }
      }
      setLoading(false);
    };

    fetchStudentData();
  }, []);

  if (loading) {
    return <div className="text-center py-8">Loading your dashboard...</div>;
  }

  if (!studentData) {
    return <Navigate to="/" />;
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800">
          Welcome back, {studentData.name}! 👋
        </h2>
        <p className="text-gray-600 mt-2">
          Class {studentData.class_level} • {studentData.district}, {studentData.state}
        </p>
        <div className="mt-2 flex gap-2">
          <Badge variant={studentData.assessment_completed ? "default" : "secondary"}>
            {studentData.assessment_completed ? "Assessment Complete" : "Assessment Pending"}
          </Badge>
          <Badge variant="outline">
            ID: {studentData.id}
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="assessment">Assessment</TabsTrigger>
          <TabsTrigger value="colleges">Colleges</TabsTrigger>
          <TabsTrigger value="courses">Courses</TabsTrigger>
          <TabsTrigger value="jobs">Jobs</TabsTrigger>
          <TabsTrigger value="news">News</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <StudentOverview student={studentData} />
        </TabsContent>

        <TabsContent value="assessment">
          <AssessmentSection student={studentData} />
        </TabsContent>

        <TabsContent value="colleges">
          <CollegeSection student={studentData} />
        </TabsContent>

        <TabsContent value="courses">
          <CourseSection student={studentData} />
        </TabsContent>

        <TabsContent value="jobs">
          <JobSection student={studentData} />
        </TabsContent>

        <TabsContent value="news">
          <NewsSection />
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Enhanced Student Overview with Charts
const StudentOverview = ({ student }) => {
  const [timeline, setTimeline] = useState([]);
  const [assessmentResults, setAssessmentResults] = useState(null);

  useEffect(() => {
    const fetchOverviewData = async () => {
      try {
        // Get relevant timeline
        const timelineResponse = await axios.get(`${API}/timeline/relevant/${student.id}`);
        setTimeline(timelineResponse.data.timeline || []);

        // Get assessment results if completed
        if (student.assessment_completed) {
          const resultsResponse = await axios.get(`${API}/students/${student.id}/assessment-results`);
          setAssessmentResults(resultsResponse.data);
        }
      } catch (error) {
        console.error('Error fetching overview data:', error);
      }
    };

    fetchOverviewData();
  }, [student]);

  const assessmentProgress = student.assessment_completed ? 100 : 0;

  return (
    <div className="space-y-6">
      {/* Progress Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="hover-lift">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              Your Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Profile Completion</span>
                  <span>100%</span>
                </div>
                <Progress value={100} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>AI Assessment</span>
                  <span>{assessmentProgress}%</span>
                </div>
                <Progress value={assessmentProgress} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-lift">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-green-600" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {!student.assessment_completed && (
              <Button className="w-full" onClick={() => window.location.href = `/assessment/${student.id}`}>
                Take AI Assessment
              </Button>
            )}
            <Button variant="outline" className="w-full" onClick={() => window.location.href = '/colleges'}>
              Find Real Colleges
            </Button>
            <Button variant="outline" className="w-full" onClick={() => window.location.href = '/courses'}>
              Explore Courses
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-lift">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-orange-600" />
              Relevant Exams
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {timeline.slice(0, 3).map((event, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                  <div>
                    <p className="text-sm font-medium">{event.exam_name}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(event.registration_start).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
              {timeline.length === 0 && (
                <p className="text-sm text-gray-500">Complete assessment to see relevant exams</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Assessment Results Charts */}
      {assessmentResults && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="hover-lift">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Stream Preferences
              </CardTitle>
              <CardDescription>Your aptitude for different academic streams</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={Object.entries(assessmentResults.stream_percentages).map(([name, value]) => ({
                      name,
                      value: parseFloat(value),
                      fill: STREAM_COLORS[name] || '#8884d8'
                    }))}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({name, value}) => `${name}: ${value}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {Object.entries(assessmentResults.stream_percentages).map(([name], index) => (
                      <Cell key={`cell-${index}`} fill={STREAM_COLORS[name] || '#8884d8'} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="hover-lift">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-green-600" />
                Course Recommendations
              </CardTitle>
              <CardDescription>Degree programs matching your interests</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={Object.entries(assessmentResults.course_percentages).map(([name, value]) => ({
                  name,
                  value: parseFloat(value),
                  fill: COURSE_COLORS[name] || '#8884d8'
                }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#8884d8">
                    {Object.entries(assessmentResults.course_percentages).map(([name], index) => (
                      <Cell key={`cell-${index}`} fill={COURSE_COLORS[name] || '#8884d8'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* AI Analysis */}
      {assessmentResults?.assessment_results?.ai_analysis && (
        <Card className="hover-lift">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-600" />
              AI Career Analysis
            </CardTitle>
            <CardDescription>Personalized insights based on your assessment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <h4 className="font-medium mb-2">Your Strengths</h4>
                <ul className="space-y-1">
                  {assessmentResults.assessment_results.ai_analysis.strengths?.map((strength, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center gap-2">
                      <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                      {strength}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Career Suggestions</h4>
                <ul className="space-y-1">
                  {assessmentResults.assessment_results.ai_analysis.career_suggestions?.map((career, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center gap-2">
                      <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                      {career}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Next Steps</h4>
                <ul className="space-y-1">
                  {assessmentResults.assessment_results.ai_analysis.next_steps?.map((step, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center gap-2">
                      <div className="w-1 h-1 bg-orange-500 rounded-full"></div>
                      {step}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>AI Reasoning:</strong> {assessmentResults.assessment_results.ai_analysis.reasoning}
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

// Enhanced Assessment Section
const AssessmentSection = ({ student }) => {
  if (student.assessment_completed) {
    const topStream = Object.entries(student.stream_percentages || {})
      .sort(([,a], [,b]) => b - a)[0];
    
    return (
      <Card className="hover-lift">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-green-600" />
            Assessment Completed ✅
          </CardTitle>
          <CardDescription>
            Your AI-powered career assessment is complete!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-medium text-green-800">Top Recommendation:</h4>
              <p className="text-green-700">
                {topStream ? `${topStream[0]} Stream (${topStream[1]}% match)` : 'Science Stream'}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium mb-2">Stream Percentages:</h4>
                <div className="space-y-2">
                  {Object.entries(student.stream_percentages || {}).map(([stream, percentage]) => (
                    <div key={stream} className="flex justify-between items-center">
                      <span className="text-sm">{stream}</span>
                      <Badge style={{backgroundColor: STREAM_COLORS[stream]}} className="text-white">
                        {percentage}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Course Preferences:</h4>
                <div className="space-y-2">
                  {Object.entries(student.course_percentages || {}).slice(0, 3).map(([course, percentage]) => (
                    <div key={course} className="flex justify-between items-center">
                      <span className="text-sm">{course}</span>
                      <Badge style={{backgroundColor: COURSE_COLORS[course]}} className="text-white">
                        {percentage}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <Button onClick={() => window.location.href = `/assessment/${student.id}`} variant="outline">
              Retake Assessment
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover-lift">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GraduationCap className="h-5 w-5 text-blue-600" />
          AI Career Assessment
        </CardTitle>
        <CardDescription>
          Take our comprehensive AI-powered assessment to discover your ideal career path
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-orange-600">
            <AlertCircle className="h-5 w-5" />
            <span>Assessment not started</span>
          </div>
          <p className="text-gray-600">
            Our OpenAI-powered assessment will analyze your interests, personality, and aptitude 
            to provide personalized stream and course recommendations with visual analytics.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>AI-Generated Questions</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>Visual Results</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
              <span>Stream Analysis</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span>Course Matching</span>
            </div>
          </div>
          <Button 
            onClick={() => window.location.href = `/assessment/${student.id}`}
            className="w-full"
          >
            Start AI Assessment (Min 10 Questions)
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

// Enhanced Assessment Flow Component
const EnhancedAssessmentFlow = () => {
  const studentId = window.location.pathname.split('/')[2];
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [totalAnswered, setTotalAnswered] = useState(0);
  const [questionsRemaining, setQuestionsRemaining] = useState(10);
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [results, setResults] = useState(null);

  const fetchNextQuestion = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API}/assessment/questions?student_id=${studentId}`);
      
      if (response.data.questions && response.data.questions.length > 0) {
        setCurrentQuestion(response.data.questions[0]);
        setTotalAnswered(response.data.total_answered);
        setQuestionsRemaining(response.data.questions_remaining || 0);
      } else {
        // Assessment might be complete
        setCompleted(true);
      }
    } catch (error) {
      console.error('Error fetching question:', error);
      alert('Error loading questions. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNextQuestion();
  }, []);

  const handleResponse = async (selectedOption) => {
    if (!currentQuestion) return;

    setLoading(true);
    try {
      const response = await axios.post(`${API}/assessment/submit`, {
        student_id: studentId,
        question_id: currentQuestion.id,
        selected_option: selectedOption
      });

      if (response.data.assessment_complete) {
        setCompleted(true);
        setResults(response.data.results);
      } else {
        // Fetch next question
        await fetchNextQuestion();
      }
    } catch (error) {
      console.error('Error submitting response:', error);
      alert('Error submitting response. Please try again.');
      setLoading(false);
    }
  };

  if (completed) {
    return (
      <Card className="max-w-4xl mx-auto hover-lift">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-6 w-6 text-green-600" />
            Assessment Complete! 🎉
          </CardTitle>
          <CardDescription>
            Your AI-powered career analysis is ready
          </CardDescription>
        </CardHeader>
        <CardContent>
          {results && (
            <div className="space-y-6">
              {/* Results Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-800 mb-2">Recommended Stream</h4>
                  <p className="text-2xl font-bold text-blue-900">
                    {results.recommended_stream}
                  </p>
                  <p className="text-sm text-blue-600">
                    {results.confidence_score ? `${Math.round(results.confidence_score * 100)}% confidence` : ''}
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-800 mb-2">Top Courses</h4>
                  <div className="space-y-1">
                    {results.recommended_courses?.slice(0, 3).map((course, index) => (
                      <Badge key={index} className="mr-2" style={{backgroundColor: COURSE_COLORS[course]}}>
                        {course}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              {/* Visual Charts */}
              {results.stream_percentages && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-4">Stream Analysis</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie
                          data={Object.entries(results.stream_percentages).map(([name, value]) => ({
                            name,
                            value: parseFloat(value),
                            fill: STREAM_COLORS[name] || '#8884d8'
                          }))}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({name, value}) => `${name}: ${value}%`}
                          outerRadius={70}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {Object.entries(results.stream_percentages).map(([name], index) => (
                            <Cell key={`cell-${index}`} fill={STREAM_COLORS[name] || '#8884d8'} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  <div>
                    <h4 className="font-medium mb-4">Course Preferences</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={Object.entries(results.course_percentages || {}).map(([name, value]) => ({
                        name,
                        value: parseFloat(value)
                      }))}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="value" fill="#8884d8">
                          {Object.entries(results.course_percentages || {}).map(([name], index) => (
                            <Cell key={`cell-${index}`} fill={COURSE_COLORS[name] || '#8884d8'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              <Button 
                onClick={() => window.location.href = `/student/${studentId}`}
                className="w-full"
              >
                View Complete Dashboard & Recommendations
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-8 text-center">
          <div className="animate-pulse">
            <GraduationCap className="h-12 w-12 mx-auto mb-4 text-blue-600" />
            <p>Loading AI-generated question...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!currentQuestion) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-8 text-center">
          <p>No questions available. Please try again.</p>
          <Button onClick={() => window.location.href = `/student/${studentId}`} className="mt-4">
            Back to Dashboard
          </Button>
        </CardContent>
      </Card>
    );
  }

  const progressPercentage = totalAnswered > 0 ? (totalAnswered / (totalAnswered + questionsRemaining)) * 100 : 0;

  return (
    <Card className="max-w-2xl mx-auto hover-lift">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>AI Career Assessment</CardTitle>
          <Badge variant="outline">
            Question {totalAnswered + 1} of {totalAnswered + questionsRemaining + 1}
          </Badge>
        </div>
        <Progress value={progressPercentage} className="mt-2" />
        <CardDescription>
          Answer honestly for the most accurate career recommendations
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="p-4 bg-gray-50 rounded-lg">
            <h3 className="text-lg font-medium mb-4">{currentQuestion.question}</h3>
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full text-left justify-start h-auto p-4 hover:bg-blue-50 hover:border-blue-300 transition-all"
                  onClick={() => handleResponse(index)}
                  disabled={loading}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full border-2 border-gray-300 flex items-center justify-center text-sm font-medium">
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span>{option}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          <div className="flex justify-between items-center text-sm text-gray-500">
            <span>Questions answered: {totalAnswered}</span>
            <span>Remaining: {questionsRemaining}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// College Section Component with Real Data
const CollegeSection = ({ student }) => {
  const [colleges, setColleges] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchColleges = async () => {
      try {
        const response = await axios.get(`${API}/colleges/search?state=${student.state}&district=${student.district}`);
        setColleges(response.data.colleges);
      } catch (error) {
        console.error('Error fetching colleges:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchColleges();
  }, [student]);

  const bookmarkCollege = async (collegeId) => {
    try {
      await axios.post(`${API}/students/${student.id}/bookmark-college?college_id=${collegeId}`);
      alert('College bookmarked! Check your timeline for relevant deadlines.');
    } catch (error) {
      console.error('Error bookmarking college:', error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading real government colleges...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Government Colleges Near You</h3>
        <Badge variant="outline">{colleges.length} Real Colleges Found</Badge>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {colleges.slice(0, 6).map((college, index) => (
          <CollegeCard key={index} college={college} onBookmark={() => bookmarkCollege(college.id)} />
        ))}
      </div>

      {colleges.length === 0 && (
        <Card className="p-8 text-center">
          <p className="text-gray-500">No government colleges found in your area.</p>
          <Button 
            onClick={() => window.location.href = '/colleges'} 
            className="mt-4"
          >
            Search All India Colleges
          </Button>
        </Card>
      )}
    </div>
  );
};

const CollegeCard = ({ college, onBookmark }) => (
  <Card className="hover-lift college-card">
    <CardHeader>
      <div className="flex justify-between items-start">
        <div>
          <CardTitle className="text-lg">{college.name}</CardTitle>
          <CardDescription className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            {college.city}, {college.state}
          </CardDescription>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onBookmark}
          className="text-orange-600 hover:text-orange-700"
        >
          <Bookmark className="h-4 w-4" />
        </Button>
      </div>
    </CardHeader>
    <CardContent>
      <div className="space-y-3">
        <div>
          <span className="text-sm font-medium">Courses Offered:</span>
          <div className="mt-1 flex flex-wrap gap-1">
            {college.courses_offered?.slice(0, 4).map((course, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {course.name}
              </Badge>
            ))}
          </div>
        </div>
        <div>
          <span className="text-sm font-medium">Facilities:</span>
          <p className="text-sm text-gray-600">{college.facilities?.join(', ')}</p>
        </div>
        {college.website && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => window.open(college.website, '_blank')}
            className="w-full"
          >
            Visit Official Website
          </Button>
        )}
      </div>
    </CardContent>
  </Card>
);

// Course Section Component with Real Data
const CourseSection = ({ student }) => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const response = await axios.get(`${API}/courses`);
        setCourses(response.data.courses);
      } catch (error) {
        console.error('Error fetching courses:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);

  const bookmarkCourse = async (courseId) => {
    try {
      await axios.post(`${API}/students/${student.id}/bookmark-course?course_id=${courseId}`);
      alert('Course bookmarked! Check your timeline for relevant exam dates.');
    } catch (error) {
      console.error('Error bookmarking course:', error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading real government courses...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Government Approved Courses</h3>
        <Badge variant="outline">{courses.length} UGC Approved Courses</Badge>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {courses.map((course, index) => (
          <CourseCard key={index} course={course} onBookmark={() => bookmarkCourse(course.id)} />
        ))}
      </div>
    </div>
  );
};

const CourseCard = ({ course, onBookmark }) => (
  <Card className="hover-lift course-card">
    <CardHeader>
      <div className="flex justify-between items-start">
        <div>
          <CardTitle className="text-lg">{course.name}</CardTitle>
          <CardDescription>{course.stream} • {course.duration}</CardDescription>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onBookmark}
          className="text-orange-600 hover:text-orange-700"
        >
          <Bookmark className="h-4 w-4" />
        </Button>
      </div>
    </CardHeader>
    <CardContent>
      <div className="space-y-3">
        <div>
          <span className="text-sm font-medium">Career Prospects:</span>
          <ul className="text-sm text-gray-600 list-disc list-inside mt-1">
            {course.career_prospects?.slice(0, 3).map((prospect, index) => (
              <li key={index}>{prospect}</li>
            ))}
          </ul>
        </div>
        <div>
          <span className="text-sm font-medium">Starting Salary:</span>
          <p className="text-sm font-semibold text-green-600">{course.average_salary?.entry}</p>
        </div>
        <div>
          <span className="text-sm font-medium">Entrance Exams:</span>
          <div className="flex flex-wrap gap-1 mt-1">
            {course.entrance_exams?.slice(0, 3).map((exam, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {exam}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </CardContent>
  </Card>
);

// Job Section Component (keeping existing functionality)
const JobSection = ({ student }) => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchJobs('entry level jobs india');
  }, []);

  const fetchJobs = async (query) => {
    try {
      setLoading(true);
      const response = await axios.get(`${API}/jobs/search?query=${query}&location=${student.state}`);
      setJobs(response.data.jobs);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      fetchJobs(searchQuery);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          placeholder="Search for jobs..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
        />
        <Button onClick={handleSearch}>Search</Button>
      </div>

      {loading ? (
        <div className="text-center py-8">Loading live job opportunities...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {jobs.slice(0, 6).map((job, index) => (
            <JobCard key={index} job={job} />
          ))}
        </div>
      )}
    </div>
  );
};

const JobCard = ({ job }) => (
  <Card className="hover-lift job-card">
    <CardHeader>
      <CardTitle className="text-lg">{job.title}</CardTitle>
      <CardDescription>{job.company} • {job.location}</CardDescription>
    </CardHeader>
    <CardContent>
      <div className="space-y-2">
        <div>
          <span className="text-sm font-medium">Salary:</span>
          <span className="text-sm text-green-600 ml-2 font-semibold">{job.salary_range}</span>
        </div>
        <div>
          <span className="text-sm font-medium">Experience:</span>
          <span className="text-sm text-gray-600 ml-2">{job.experience_required}</span>
        </div>
        <div>
          <span className="text-sm font-medium">Education:</span>
          <span className="text-sm text-gray-600 ml-2">{job.education_required}</span>
        </div>
        {job.skills_required && job.skills_required.length > 0 && (
          <div>
            <span className="text-sm font-medium">Skills:</span>
            <div className="flex flex-wrap gap-1 mt-1">
              {job.skills_required.slice(0, 3).map((skill, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        )}
        {job.apply_url && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => window.open(job.apply_url, '_blank')}
            className="w-full mt-2"
          >
            Apply Now
          </Button>
        )}
      </div>
    </CardContent>
  </Card>
);

// News Section Component (keeping existing functionality)
const NewsSection = () => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await axios.get(`${API}/news?category=education`);
        setNews(response.data.news);
      } catch (error) {
        console.error('Error fetching news:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, []);

  if (loading) {
    return <div className="text-center py-8">Loading latest education news...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Latest Education News</h3>
        <Badge variant="outline">{news.length} Live Articles</Badge>
      </div>
      <div className="space-y-4">
        {news.slice(0, 8).map((item, index) => (
          <NewsCard key={index} news={item} />
        ))}
      </div>
    </div>
  );
};

const NewsCard = ({ news }) => (
  <Card className="hover-lift news-card">
    <CardContent className="p-4">
      <div className="space-y-2">
        <div className="flex justify-between items-start">
          <h4 className="font-medium text-lg leading-tight">{news.title}</h4>
          <Badge variant="outline" className="ml-2 text-xs">
            {news.source}
          </Badge>
        </div>
        <p className="text-sm text-gray-600">{news.description}</p>
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">
            {new Date(news.published_at).toLocaleDateString()}
          </span>
          <Button 
            variant="link" 
            size="sm" 
            onClick={() => window.open(news.url, '_blank')}
          >
            Read More →
          </Button>
        </div>
      </div>
    </CardContent>
  </Card>
);

// College Explorer (standalone page)
const CollegeExplorer = () => {
  const [colleges, setColleges] = useState([]);
  const [filters, setFilters] = useState({
    state: '',
    course: '',
    type: 'Government'
  });
  const [loading, setLoading] = useState(false);

  const searchColleges = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.state) params.append('state', filters.state);
      if (filters.course) params.append('course', filters.course);
      
      const response = await axios.get(`${API}/colleges/search?${params.toString()}`);
      setColleges(response.data.colleges);
    } catch (error) {
      console.error('Error searching colleges:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    searchColleges();
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">Government College Explorer</h2>
      
      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>State</Label>
              <Input
                placeholder="Enter state"
                value={filters.state}
                onChange={(e) => setFilters({...filters, state: e.target.value})}
              />
            </div>
            <div>
              <Label>Course</Label>
              <Input
                placeholder="Enter course"
                value={filters.course}
                onChange={(e) => setFilters({...filters, course: e.target.value})}
              />
            </div>
            <div className="md:col-span-2 flex items-end">
              <Button onClick={searchColleges} disabled={loading} className="w-full">
                {loading ? 'Searching Real Colleges...' : 'Search Colleges'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {colleges.map((college, index) => (
          <CollegeCard key={index} college={college} onBookmark={() => {}} />
        ))}
      </div>

      {colleges.length === 0 && !loading && (
        <div className="text-center py-8 text-gray-500">
          No colleges found. Try adjusting your search criteria.
        </div>
      )}
    </div>
  );
};

// Course Explorer (standalone page)
const CourseExplorer = () => {
  const [courses, setCourses] = useState([]);
  const [selectedStream, setSelectedStream] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const params = selectedStream ? `?stream=${selectedStream}` : '';
        const response = await axios.get(`${API}/courses${params}`);
        setCourses(response.data.courses);
      } catch (error) {
        console.error('Error fetching courses:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, [selectedStream]);

  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">Government Approved Courses</h2>
      
      {/* Stream Filter */}
      <div className="mb-6">
        <Tabs value={selectedStream} onValueChange={setSelectedStream}>
          <TabsList>
            <TabsTrigger value="">All Streams</TabsTrigger>
            <TabsTrigger value="Science">Science</TabsTrigger>
            <TabsTrigger value="Commerce">Commerce</TabsTrigger>
            <TabsTrigger value="Arts">Arts</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {loading ? (
        <div className="text-center py-8">Loading UGC approved courses...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course, index) => (
            <CourseCard key={index} course={course} onBookmark={() => {}} />
          ))}
        </div>
      )}
    </div>
  );
};

// News Updates (standalone page)
const NewsUpdates = () => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await axios.get(`${API}/news?category=education`);
        setNews(response.data.news);
      } catch (error) {
        console.error('Error fetching news:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, []);

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">Education News & Updates</h2>
      
      {loading ? (
        <div className="text-center py-8">Loading latest education news...</div>
      ) : (
        <div className="space-y-6">
          {news.map((item, index) => (
            <NewsCard key={index} news={item} />
          ))}
        </div>
      )}
    </div>
  );
};

// Job Opportunities (standalone page)
const JobOpportunities = () => {
  const [jobs, setJobs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('India');
  const [loading, setLoading] = useState(false);

  const searchJobs = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {
      const response = await axios.get(`${API}/jobs/search?query=${searchQuery}&location=${location}`);
      setJobs(response.data.jobs);
    } catch (error) {
      console.error('Error searching jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">Live Job Opportunities</h2>
      
      {/* Search */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Job Title/Keywords</Label>
              <Input
                placeholder="e.g., Software Engineer, Teacher"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && searchJobs()}
              />
            </div>
            <div>
              <Label>Location</Label>
              <Input
                placeholder="City, State"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
            <div className="flex items-end">
              <Button onClick={searchJobs} disabled={loading} className="w-full">
                {loading ? 'Searching Jobs...' : 'Search Jobs'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {jobs.map((job, index) => (
          <JobCard key={index} job={job} />
        ))}
      </div>

      {jobs.length === 0 && searchQuery && !loading && (
        <div className="text-center py-8 text-gray-500">
          No jobs found for "{searchQuery}". Try different keywords.
        </div>
      )}
    </div>
  );
};

export default App;